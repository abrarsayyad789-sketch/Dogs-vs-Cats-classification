
# Dogs vs Cats CNN Classifier

This project trains a simple Convolutional Neural Network to classify images of cats and dogs using TensorFlow/Keras.

## Files
- train.py : trains the CNN model
- requirements.txt : required Python libraries

## How to run
1. Install dependencies:
   pip install -r requirements.txt

2. Download the Kaggle Dogs vs Cats dataset and place it in a folder named `data/` with two subfolders:
   data/train/cats
   data/train/dogs

3. Run training:
   python train.py
